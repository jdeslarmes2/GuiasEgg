package com.egg.biblioteca3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Biblioteca3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
